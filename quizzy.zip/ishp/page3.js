

function changeBg(x, category){
     localStorage.setItem('bg',x);

     localStorage.setItem('category', `${category}`);
}